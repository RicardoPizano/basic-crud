=====
Basic CRUD
=====


Detailed documentation is in the "docs" directory.

Quick start
-----------

1. 

2. 

3. 

4. 

5. 